import React, { useMemo, useState } from 'react';
import { BookOpen, ExternalLink, Search, LibraryBig, BookMarked } from 'lucide-react';

const collections = [
  {
    id: 'seerah',
    title: 'السيرة النبوية',
    description: 'كتب السيرة والمغازي والشمائل من فهارس المكتبات التراثية.',
    icon: 'السيرة',
    books: [
      { title: 'السيرة النبوية لابن هشام', author: 'عبد الملك بن هشام', source: 'المكتبة الشاملة', url: 'https://shamela.ws/book/23833' },
      { title: 'سيرة ابن إسحاق: السير والمغازي', author: 'محمد بن إسحاق', source: 'المكتبة الشاملة', url: 'https://shamela.ws/book/9862' },
      { title: 'مغازي الواقدي', author: 'محمد بن عمر الواقدي', source: 'المكتبة الشاملة', url: 'https://shamela.ws/book/23680' },
      { title: 'تصفّح جميع كتب السيرة', author: 'فهرس مصنّف حسب الموضوع', source: 'المكتبة الشاملة', url: 'https://shamela.ws/category/24' },
    ],
  },
  {
    id: 'tafsir',
    title: 'التفسير وعلوم القرآن',
    description: 'فهارس كتب التفسير وعلوم القرآن، مع روابط للنصوص والطبعات المتاحة لدى المصدر.',
    icon: 'التفسير',
    books: [
      { title: 'أضواء البيان في إيضاح القرآن بالقرآن', author: 'محمد الأمين الشنقيطي', source: 'المكتبة الوقفية', url: 'https://waqfeya.net/books/%D8%A3%D8%B6%D9%88%D8%A7%D8%A1-%D8%A7%D9%84%D8%A8%D9%8A%D8%A7%D9%86-%D9%81%D9%8A-%D8%A5%D9%8A%D8%B6%D8%A7%D8%AD-%D8%A7%D9%84%D9%82%D8%B1%D8%A2%D9%86-%D8%A8%D8%A7%D9%84%D9%82%D8%B1%D8%A2%D9%86-%D8%B7-%D9%85%D8%AC%D9%85%D8%B9-%D8%A7%D9%84%D9%81%D9%82%D9%87-ff2087e54da94ee885ac48a5f46ae4d0' },
      { title: 'كتب التفاسير وعلوم القرآن', author: 'تصفّح الفهرس وابحث باسم الكتاب أو المؤلف', source: 'المكتبة الوقفية', url: 'https://waqfeya.net/' },
      { title: 'إصدارات التفسير وعلوم القرآن', author: 'بوابة رسمية لمجمع الملك فهد لطباعة المصحف الشريف', source: 'مجمع الملك فهد', url: 'https://qurancomplex.gov.sa/' },
    ],
  },
  {
    id: 'fiqh',
    title: 'الفقه وأصوله',
    description: 'فهارس كتب الفقه والمذاهب وأصول الفقه للبحث والقراءة من المصدر.',
    icon: 'الفقه',
    books: [
      { title: 'كتب الفقه العام والمذاهب', author: 'تصفّح الفهارس وابحث باسم الكتاب أو المؤلف', source: 'المكتبة الوقفية', url: 'https://waqfeya.net/' },
      { title: 'كتب الفقه وأصوله', author: 'مكتبة نصية قابلة للبحث', source: 'المكتبة الشاملة', url: 'https://shamela.ws/' },
      { title: 'المكتبة الوقفية للكتب المصورة', author: 'مشروع غير ربحي لخدمة طلبة العلم والباحثين', source: 'المكتبة الوقفية', url: 'https://waqfeya.net/' },
    ],
  },
];

export function IslamicLibraryPage() {
  const [activeId, setActiveId] = useState('seerah');
  const [search, setSearch] = useState('');
  const active = collections.find((collection) => collection.id === activeId) || collections[0];
  const books = useMemo(() => {
    const query = search.trim().toLocaleLowerCase('ar');
    return active.books.filter((book) => !query || `${book.title} ${book.author} ${book.source}`.toLocaleLowerCase('ar').includes(query));
  }, [active, search]);

  return (
    <main className="max-w-6xl mx-auto px-4 py-8 sm:px-6" dir="rtl">
      <section className="rounded-3xl border border-emerald-100 dark:border-emerald-900 bg-gradient-to-l from-emerald-50 to-white dark:from-emerald-950/50 dark:to-slate-900 p-6 sm:p-9">
        <div className="flex items-center gap-3 text-emerald-700 dark:text-emerald-300">
          <LibraryBig className="h-8 w-8" />
          <span className="font-bold">قراءة وبحث من مصادرها</span>
        </div>
        <h1 className="mt-4 text-3xl sm:text-4xl font-black text-slate-900 dark:text-white">المكتبة الإسلامية</h1>
        <p className="mt-3 max-w-3xl leading-8 text-slate-600 dark:text-slate-300">فهرس منظم للسيرة والتفسير والفقه. افتح الكتاب من مكتبته الأصلية للاطلاع على النص الكامل والطبعة وبيانات التحقيق المتاحة لدى المصدر.</p>
      </section>
      <nav className="mt-6 flex flex-wrap gap-2" aria-label="تصنيفات المكتبة">
        {collections.map((collection) => (
          <button key={collection.id} type="button" onClick={() => setActiveId(collection.id)} aria-pressed={activeId === collection.id} className={`rounded-xl px-4 py-3 text-sm font-bold transition ${activeId === collection.id ? 'bg-emerald-700 text-white' : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200'}`}>
            <BookMarked className="inline-block h-4 w-4 ml-2" />{collection.title}
          </button>
        ))}
      </nav>
      <section className="mt-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div><h2 className="text-2xl font-black text-slate-900 dark:text-white">{active.title}</h2><p className="mt-2 text-sm text-slate-500 dark:text-slate-400">{active.description}</p></div>
          <label className="relative w-full sm:max-w-xs">
            <Search className="absolute right-3 top-3 h-4 w-4 text-slate-400" />
            <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="ابحث في هذا القسم" className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 py-2.5 pr-10 pl-3 text-sm outline-none focus:ring-2 focus:ring-emerald-600" />
          </label>
        </div>
        <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {books.map((book) => (
            <a key={book.title} href={book.url} target="_blank" rel="noopener noreferrer" className="group flex min-h-36 flex-col justify-between rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 transition hover:border-emerald-500 hover:shadow-md">
              <div><div className="flex items-start justify-between gap-3"><h3 className="font-black leading-7 text-slate-900 dark:text-white">{book.title}</h3><ExternalLink className="h-4 w-4 shrink-0 text-emerald-700 dark:text-emerald-300" /></div><p className="mt-2 text-sm leading-6 text-slate-500 dark:text-slate-400">{book.author}</p></div>
              <div className="mt-4 flex items-center gap-2 text-xs font-bold text-emerald-700 dark:text-emerald-300"><BookOpen className="h-4 w-4" />{book.source}</div>
            </a>
          ))}
          {books.length === 0 && <p className="col-span-full rounded-xl bg-slate-100 dark:bg-slate-800 p-5 text-sm text-slate-500">لا توجد نتائج مطابقة في هذا القسم.</p>}
        </div>
        <p className="mt-6 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm leading-7 text-amber-900 dark:border-amber-900 dark:bg-amber-950/30 dark:text-amber-200">روابط القراءة تفتح لدى الجهات الناشرة أو المكتبات الأصلية. توافر النص أو النسخة المصورة وحقوق إعادة النشر تحددها كل مكتبة؛ لذلك لا تُنسخ الكتب إلى ملفات الموقع.</p>
      </section>
    </main>
  );
}
