import React, { lazy, Suspense, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { useAuth } from '../../context/AuthContext.jsx';
import { useTheme } from '../../context/ThemeContext.jsx';
import { useAdminNotes } from '../../hooks/useAdminNotes.js';
import {
  CalendarDays,
  TrendingUp,
  History,
  User,
  Shield,
  LogOut,
  Flame,
  CheckCircle2,
  MessageCircle,
  X,
  ChevronDown,
  Sun,
  Moon,
  CircleDot,
  BookOpen,
  Award,
  CheckSquare,
} from 'lucide-react';
import { formatArabicDate, getTodayDateString } from '../../lib/dates.js';
import { Logo } from './Logo.jsx';
import { MessageThreadCard } from '../MessageThreadCard.jsx';
import { SyncStatusBadge } from '../SyncStatusBadge.jsx';

const QuranReaderModal = lazy(() =>
  import('../QuranReaderModal.jsx').then((module) => ({ default: module.QuranReaderModal })),
);
const OfflineDownloadModal = lazy(() =>
  import('../OfflineDownloadModal.jsx').then((module) => ({ default: module.OfflineDownloadModal })),
);

export function Shell({
  currentTab,
  onSelectTab,
  currentStreak = 0,
  totalPoints = 0,
  showOfflineSetup = false,
  onOfflineSetupDismiss,
  children,
}) {
  const { user, userDoc, isAdmin, logout } = useAuth();
  const { toggleTheme, isDark } = useTheme();
  const {
    notes,
    loading: notesLoading,
    error: notesError,
    markAsRead,
    replyToNote,
  } = useAdminNotes();
  const [notesOpen, setNotesOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const userMenuButtonRef = useRef(null);
  const shellHeaderRef = useRef(null);
  const [userMenuPosition, setUserMenuPosition] = useState(null);
  const [quranOpen, setQuranOpen] = useState(false);
  const quranHistoryEntryRef = useRef(false);
  const [offlineOpen, setOfflineOpen] = useState(false);
  const [notesReadError, setNotesReadError] = useState(null);
  const readAttemptsRef = useRef(new Set());

  React.useEffect(() => {
    const handleBrowserBack = () => {
      if (!quranHistoryEntryRef.current) return;
      quranHistoryEntryRef.current = false;
      setQuranOpen(false);
    };
    window.addEventListener('popstate', handleBrowserBack);
    return () => window.removeEventListener('popstate', handleBrowserBack);
  }, []);

  const openQuran = () => {
    if (!quranHistoryEntryRef.current) {
      // Add a same-page guard entry first, then the Quran entry. The first
      // browser Back now returns to this app page and closes the reader,
      // even when the user opened the app directly from an external link.
      window.history.pushState(
        { ...(window.history.state || {}), mutabiQuranBase: true },
        '',
        window.location.href,
      );
      window.history.pushState(
        { ...(window.history.state || {}), mutabiQuranOpen: true },
        '',
        window.location.href,
      );
      quranHistoryEntryRef.current = true;
    }
    setQuranOpen(true);
  };

  const closeQuran = () => {
    const hasQuranHistoryEntry = quranHistoryEntryRef.current;
    quranHistoryEntryRef.current = false;
    setQuranOpen(false);
    if (hasQuranHistoryEntry) window.history.back();
  };

  React.useEffect(() => {
    if (showOfflineSetup) setOfflineOpen(true);
  }, [showOfflineSetup]);

  React.useEffect(() => {
    if (!userMenuOpen) {
      setUserMenuPosition(null);
      return undefined;
    }

    const updateUserMenuPosition = () => {
      const button = userMenuButtonRef.current;
      if (!button) return;
      const rect = button.getBoundingClientRect();
      const headerBottom = shellHeaderRef.current?.getBoundingClientRect().bottom || rect.bottom;
      const menuWidth = Math.min(224, Math.max(208, window.innerWidth - 16));
      const left = Math.min(
        Math.max(8, rect.right - menuWidth),
        Math.max(8, window.innerWidth - menuWidth - 8),
      );
      // Keep the menu outside the header, over the page content itself.
      const below = Math.max(rect.bottom + 12, headerBottom + 12);
      setUserMenuPosition({ top: below, left, width: menuWidth });
    };

    updateUserMenuPosition();
    window.addEventListener('resize', updateUserMenuPosition);
    window.addEventListener('scroll', updateUserMenuPosition, true);
    return () => {
      window.removeEventListener('resize', updateUserMenuPosition);
      window.removeEventListener('scroll', updateUserMenuPosition, true);
    };
  }, [userMenuOpen]);

  React.useEffect(() => {
    const openOfflineModal = () => setOfflineOpen(true);
    window.addEventListener('mutabi:open-offline-modal', openOfflineModal);
    return () => window.removeEventListener('mutabi:open-offline-modal', openOfflineModal);
  }, []);



  const closeOfflineModal = () => {
    setOfflineOpen(false);
    onOfflineSetupDismiss?.();
  };

  const unreadNotes = notes.filter((n) => !n.isRead);
  const todayStr = getTodayDateString(userDoc?.timezone);

  const handleMarkAsRead = async (noteId) => {
    try {
      await markAsRead(noteId);
      setNotesReadError(null);
    } catch (error) {
      console.error('Could not mark the message as read:', error);
      setNotesReadError('تعذر تحديث حالة الرسالة. تحقق من الاتصال أو الصلاحيات ثم أعد المحاولة.');
    }
  };

  React.useEffect(() => {
    if (!notesOpen) {
      readAttemptsRef.current.clear();
      setNotesReadError(null);
      return;
    }
    if (notesLoading || notesError) return;

    unreadNotes.forEach((note) => {
      if (readAttemptsRef.current.has(note.id)) return;
      readAttemptsRef.current.add(note.id);
      void handleMarkAsRead(note.id);
    });
  }, [notesOpen, notesLoading, notesError, unreadNotes, markAsRead]);

  const navItems = [
    { id: 'today', label: 'الورد اليومي', icon: CalendarDays },
    { id: 'todos', label: 'قائمة المهام', icon: CheckSquare },
    { id: 'tasbeeh', label: 'التسبيح والأذكار', icon: CircleDot },
    { id: 'hadith', label: 'الأحاديث النبوية', icon: BookOpen },
    { id: 'library', label: 'المكتبة الإسلامية', icon: BookOpen },
    { id: 'progress', label: 'التقدم والأوسمة', icon: TrendingUp },
    { id: 'history', label: 'سجل الإنجازات', icon: History },
    { id: 'profile', label: 'الملف الشخصي', icon: User },
  ];

  if (isAdmin) {
    navItems.push({ id: 'admin', label: 'لوحة الإدارة', icon: Shield });
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 flex flex-col font-sans transition-colors duration-200">
      {/* Top Navbar */}
      <header ref={shellHeaderRef} className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800/80 px-2.5 sm:px-6 py-2 sm:py-3 shadow-2xs max-w-full overflow-visible">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-1.5 sm:gap-4">
          {/* Logo & Brand */}
          <div
            onClick={() => onSelectTab('today')}
            className="flex items-center gap-1.5 sm:gap-3 cursor-pointer select-none shrink-0"
          >
            <Logo className="h-7 sm:h-9" />
            <div className="hidden sm:block">
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] sm:text-xs text-emerald-800 dark:text-emerald-300 font-bold bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-200 dark:border-emerald-800">
                  اليومي
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-400 dark:text-slate-500">
                {formatArabicDate(todayStr, true)}
              </p>
            </div>
          </div>

          {/* Center: Streak Badge & Points Badge */}
          <div className="flex items-center gap-1 sm:gap-2 shrink-0">
            <div
              className={`flex items-center gap-1 px-2 sm:px-3 py-1 sm:py-1.5 rounded-xl sm:rounded-2xl font-bold text-xs sm:text-sm border transition-all ${
                currentStreak > 0
                  ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300 shadow-2xs'
                  : 'bg-slate-100 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400'
              }`}
              title="سلسلة الاستمرار المتواصل"
            >
              <Flame className={`w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0 ${currentStreak > 0 ? 'fill-amber-500 text-amber-500' : 'text-slate-400'}`} />
              <span>{currentStreak}</span>
              <span className="hidden sm:inline">{currentStreak === 1 ? 'يوم' : 'أيام'}</span>
            </div>

            <button
              type="button"
              onClick={() => onSelectTab('progress')}
              className="flex items-center gap-1 px-2 sm:px-3 py-1 sm:py-1.5 rounded-xl sm:rounded-2xl font-bold text-xs sm:text-sm border bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 shadow-2xs cursor-pointer hover:scale-105 transition-all"
              title="رصيد نقاط العبادة - اضغط للانتقال إلى واجهة الميداليات"
            >
              <Award className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span>{totalPoints}</span>
              <span className="hidden sm:inline text-[10px] sm:text-xs font-semibold">نقطة</span>
            </button>
          </div>

          {/* Right Tools: Quran Reader, Theme Toggle, Notifications & User Avatar */}
          <div className="flex items-center gap-1 sm:gap-2 shrink-0">
            {/* Quran Reader with Night Mode */}
            <button
              type="button"
              onClick={openQuran}
              className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl sm:rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 dark:hover:bg-emerald-900/80 flex items-center justify-center text-emerald-700 dark:text-emerald-300 transition-all border border-emerald-200 dark:border-emerald-800 cursor-pointer shrink-0"
              title="المصحف الشريف - القراءة والوضع الليلي المريح"
              aria-label="المصحف الشريف"
            >
              <BookOpen className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-600 dark:text-emerald-400" />
            </button>

            {/* Theme Toggle Button */}
            <button
              type="button"
              onClick={toggleTheme}
              className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl sm:rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200/80 dark:hover:bg-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300 transition-all border border-slate-200/60 dark:border-slate-700 cursor-pointer shrink-0"
              title={isDark ? "التبديل إلى الوضع الفاتح" : "التبديل إلى الوضع الداكن"}
              aria-label="تبديل المظهر"
            >
              {isDark ? (
                <Sun className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400" />
              ) : (
                <Moon className="w-4 h-4 sm:w-5 sm:h-5 text-slate-600" />
              )}
            </button>

            {/* Notifications / Notes dropdown */}
            <div className="relative shrink-0">
              <button
                type="button"
                onClick={() => setNotesOpen(!notesOpen)}
                className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl sm:rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200/80 dark:hover:bg-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300 relative transition-all border border-slate-200/60 dark:border-slate-700 cursor-pointer"
                title="رسائل المشرف"
                aria-label="فتح رسائل المشرف"
                aria-expanded={notesOpen}
              >
                <MessageCircle className="w-4 h-4 sm:w-5 sm:h-5" />
                {unreadNotes.length > 0 && (
                  <span className="absolute -top-1 -end-1 w-4 h-4 sm:w-5 sm:h-5 bg-emerald-600 text-white rounded-full text-[10px] font-bold flex items-center justify-center border-2 border-white dark:border-slate-900">
                    {unreadNotes.length > 9 ? '9+' : unreadNotes.length}
                  </span>
                )}
              </button>
            </div>

            {/* User Avatar & Dropdown */}
            <div className="relative shrink-0">
              <button
                type="button"
                ref={userMenuButtonRef}
                onClick={() => setUserMenuOpen(!userMenuOpen)}
                className="flex items-center gap-1 sm:gap-2 p-0.5 sm:p-1 sm:pe-2.5 rounded-xl sm:rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200/80 dark:hover:bg-slate-700 transition-all border border-slate-200/60 dark:border-slate-700 cursor-pointer"
                aria-label="فتح قائمة الحساب"
                aria-expanded={userMenuOpen}
              >
                <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg sm:rounded-xl bg-emerald-600 text-white font-bold text-xs sm:text-sm flex items-center justify-center overflow-hidden shrink-0 shadow-2xs">
                  {userDoc?.photoURL ? (
                    <img src={userDoc.photoURL} alt={userDoc.displayName} className="w-full h-full object-cover" />
                  ) : (
                    (userDoc?.displayName?.[0] || 'م').toUpperCase()
                  )}
                </div>
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200 hidden md:inline max-w-[90px] truncate">
                  {userDoc?.displayName || 'حسابي'}
                </span>
                <ChevronDown className="w-3 h-3 text-slate-400 hidden sm:inline" />
              </button>

              {userMenuOpen && userMenuPosition && createPortal(
                <div
                  className="fixed inset-0 z-[9999]"
                  onClick={() => setUserMenuOpen(false)}
                >
                  <div
                    className="absolute rounded-3xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800 p-2 text-right animate-in fade-in"
                    style={userMenuPosition}
                    onClick={(event) => event.stopPropagation()}
                  >
                    <div className="px-3 py-2 border-b border-slate-100 dark:border-slate-800">
                      <p className="font-bold text-xs text-slate-900 dark:text-slate-100 truncate">
                        {userDoc?.displayName}
                      </p>
                      <p className="text-[10px] text-slate-400 truncate" dir="ltr">
                        {user?.email || userDoc?.email}
                      </p>
                    </div>
                    <div className="py-1">
                      <button
                        onClick={() => {
                          onSelectTab('profile');
                          setUserMenuOpen(false);
                        }}
                        className="w-full px-3 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-xl flex items-center gap-2 cursor-pointer"
                      >
                        <User className="w-3.5 h-3.5 text-slate-400" />
                        الملف الشخصي
                      </button>
                      {isAdmin && (
                        <button
                          onClick={() => {
                            onSelectTab('admin');
                            setUserMenuOpen(false);
                          }}
                          className="w-full px-3 py-2 text-xs font-bold text-emerald-700 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 rounded-xl flex items-center gap-2 cursor-pointer"
                        >
                          <Shield className="w-3.5 h-3.5 text-emerald-600" />
                          لوحة الإدارة
                        </button>
                      )}
                      <button
                        onClick={() => {
                          logout();
                          setUserMenuOpen(false);
                        }}
                        className="w-full px-3 py-2 text-xs font-semibold text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 rounded-xl flex items-center gap-2 cursor-pointer"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        تسجيل الخروج
                      </button>
                    </div>
                  </div>
                </div>,
                document.body,
              )}
            </div>
          </div>
        </div>
      </header>

      <div className="mx-auto flex w-full max-w-7xl justify-end px-3 pt-2 sm:px-6">
        <SyncStatusBadge onOpenOfflineModal={() => setOfflineOpen(true)} />
      </div>

      {notesOpen && (
        <>
          <button
            type="button"
            className="fixed inset-0 z-50 bg-slate-950/45 backdrop-blur-[2px]"
            onClick={() => setNotesOpen(false)}
            aria-label="إغلاق الرسائل"
          />
          <aside
            role="dialog"
            aria-modal="true"
            aria-labelledby="messages-panel-title"
            className="fixed inset-y-0 end-0 z-[60] flex w-full max-w-md flex-col border-s border-slate-200 bg-slate-50 shadow-2xl dark:border-slate-800 dark:bg-slate-950 animate-in slide-in-from-right duration-200"
          >
            <header className="flex items-center justify-between border-b border-slate-200 bg-white px-5 py-4 dark:border-slate-800 dark:bg-slate-900">
              <div>
                <h2 id="messages-panel-title" className="font-black text-slate-900 dark:text-white">
                  رسائل المشرف
                </h2>
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                  {notes.length} رسالة • لكل رسالة رد واحد
                </p>
              </div>
              <button
                type="button"
                onClick={() => setNotesOpen(false)}
                className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100 text-slate-600 transition hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700"
                aria-label="إغلاق لوحة الرسائل"
              >
                <X className="h-5 w-5" />
              </button>
            </header>
            <div className="flex-1 space-y-5 overflow-y-auto p-4 sm:p-5">
              {notesLoading && (
                <p className="py-8 text-center text-sm text-slate-500">جارٍ تحميل الرسائل...</p>
              )}
              {notesError && (
                <p role="alert" className="rounded-xl bg-rose-50 p-3 text-sm text-rose-700 dark:bg-rose-950/40 dark:text-rose-300">
                  تعذر تحميل الرسائل. حاول إعادة فتح اللوحة.
                </p>
              )}
              {notesReadError && (
                <p role="alert" className="rounded-xl bg-rose-50 p-3 text-sm text-rose-700 dark:bg-rose-950/40 dark:text-rose-300">
                  {notesReadError}
                </p>
              )}
              {!notesLoading && !notesError && notes.length === 0 && (
                <div className="rounded-3xl border border-dashed border-slate-300 bg-white px-6 py-12 text-center dark:border-slate-700 dark:bg-slate-900">
                  <MessageCircle className="mx-auto h-9 w-9 text-emerald-500" />
                  <p className="mt-3 font-bold text-slate-800 dark:text-slate-100">لا توجد رسائل بعد</p>
                  <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                    ستظهر هنا رسائل المشرف ويمكنك الرد على كل رسالة مرة واحدة.
                  </p>
                </div>
              )}
              {notes.map((note) => (
                <div key={note.id} className="space-y-2">
                  <MessageThreadCard note={note} canReply onReply={replyToNote} />
                  {!note.isRead && (
                    <button
                      type="button"
                      onClick={() => void handleMarkAsRead(note.id)}
                      className="ms-2 inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 hover:text-emerald-800 dark:text-emerald-400"
                    >
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      تم الاطلاع
                    </button>
                  )}
                  <div className="border-b border-slate-200/70 pt-2 dark:border-slate-800" />
                </div>
              ))}
            </div>
          </aside>
        </>
      )}

      {/* Main Layout Body */}
      <div className="flex-1 max-w-7xl mx-auto w-full px-3 sm:px-6 py-4 sm:py-6 flex gap-6 lg:gap-8">
        {/* Desktop Sidebar Navigation */}
        <aside className="w-56 shrink-0 hidden md:flex flex-col gap-3">
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-2.5 shadow-2xs space-y-1">
            {navItems.map((item) => {
              const active = currentTab === item.id || (item.id === 'admin' && currentTab.startsWith('admin'));
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectTab(item.id)}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all text-right cursor-pointer ${
                    active
                      ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 shadow-2xs border border-emerald-200/60 dark:border-emerald-800/60'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${active ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          {/* Inspirational Box */}
          <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 leading-relaxed text-right shadow-2xs">
            <p className="font-bold text-emerald-700 dark:text-emerald-400 mb-1">قَالَ رَسُولُ اللَّهِ ﷺ:</p>
            <p className="italic text-[11px] text-slate-600 dark:text-slate-400">
              «أَحَبُّ الأَعْمَالِ إِلَى اللَّهِ أَدْوَمُهَا وَإِنْ قَلَّ»
            </p>
          </div>
        </aside>

        {/* Page Main Content Area */}
        <main className="flex-1 min-w-0 pb-28 sm:pb-24 md:pb-6">
          {children}
        </main>
      </div>

      <footer dir="ltr" className="w-full px-4 pb-28 pt-2 text-center text-xs text-slate-400 dark:text-slate-500 md:pb-5">
        khalid salah — All rights reserved | 2026 ©
      </footer>

      {/* Mobile Bottom Navigation Bar */}
      <nav
        aria-label="التنقل الرئيسي"
        className="safe-area-bottom md:hidden fixed bottom-0 inset-x-0 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200/90 dark:border-slate-800 z-40 px-2 pt-1.5 flex items-center justify-start overflow-x-auto scrollbar-none shadow-lg gap-1 scroll-smooth"
      >
        {navItems.map((item) => {
          const active = currentTab === item.id || (item.id === 'admin' && currentTab.startsWith('admin'));
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`flex flex-col items-center justify-center min-w-[62px] sm:min-w-[70px] min-h-[48px] py-1 px-1 rounded-xl transition-all cursor-pointer shrink-0 ${
                active
                  ? 'text-emerald-700 dark:text-emerald-400 font-bold scale-105 bg-emerald-50/70 dark:bg-emerald-950/40'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300 text-xs font-medium'
              }`}
            >
              <Icon className="w-5 h-5 shrink-0" />
              <span className="text-[10px] leading-tight whitespace-nowrap mt-0.5">{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Quran Reader Modal */}
      {quranOpen && (
        <Suspense fallback={null}>
          <QuranReaderModal
            isOpen
            onClose={closeQuran}
            initialSurahNumber={1}
          />
        </Suspense>
      )}
      {offlineOpen && (
        <Suspense fallback={null}>
          <OfflineDownloadModal isOpen onClose={closeOfflineModal} />
        </Suspense>
      )}
    </div>
  );
}
